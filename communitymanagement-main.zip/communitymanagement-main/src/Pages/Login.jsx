import { Link } from "react-router-dom";

export default function Login() {
  return (
    <div className="flex flex-col items-start justify-center h-screen mx-20 w-1/2">
      <div id="logiHeading" className="text-5xl font-bold font-serif mb-2">
        Community Management
      </div>
      <form id="loginform" className="flex flex-col gap-5 w-full">
        <div className="form-control">
          <label className="label">
            <span className="label-text">Mobile No</span>
          </label>
          <input
            className="input input-bordered"
            maxLength={10}
            type="number"
            placeholder="Mobile no"
          />
        </div>
        <div className="form-control">
          <label className="label">
            <span className="label-text ">Password</span>
          </label>
          <input className="input input-bordered " placeholder="Password" />
        </div>
        <div className="form-control mt-5">
          <button className="btn btn-success">Login</button>
        </div>
        <div className="flex justify-center items-center">
          <p> Need a new Account ?</p>

          <Link to="/signup" className="text-success font-bold">
            Signup
          </Link>
        </div>
      </form>
    </div>
  );
}
