export default function Signup() {
  return (
    <div className="h-screen flex items-center justify-center flex-col gap-5">
      <div
        id="signupHeading"
        className="text-5xl font-bold font-serif mb-2 w-full"
      >
        Signup
      </div>
      <form
        id="loginform"
        className="grid grid-flow-col grid-cols-2 grid-rows-3 gap-5"
      >
        <div className="form-control w-full">
          <label className="label">
            <span className="label-text">Username</span>
          </label>
          <input className="input input-bordered " placeholder="User Name" />
        </div>
        <div className="form-control">
          <label className="label">
            <span className="label-text">Eamil</span>
          </label>
          <input className="input input-bordered " placeholder="Email" />
        </div>
        <div className="form-control">
          <label className="label">
            <span className="label-text">Mobile No</span>
          </label>
          <input className="input input-bordered " placeholder="Number" />
        </div>
        <div className="form-control">
          <label className="label">
            <span className="label-text">Ward Name</span>
          </label>
          <input className="input input-bordered " placeholder="Ward Name" />
        </div>
        <div className="form-control">
          <label className="label">
            <span className="label-text">Area Name</span>
          </label>
          <input className="input input-bordered " placeholder="Area Name" />
        </div>
        <div className="form-control">
          <label className="label">
            <span className="label-text ">Password</span>
          </label>
          <input className="input input-bordered " placeholder="Password" />
        </div>
        <div className="form-control col-start-3 row-start-3 mt-9">
          <button className="btn btn-success">Sign up</button>
        </div>
        {/* <div className="flex justify-center items-center">
              <p> Already Have a Account ?</p>

              <Link to="/login" className="text-success font-bold">
                Login
              </Link>
            </div> */}
      </form>
    </div>
  );
}
