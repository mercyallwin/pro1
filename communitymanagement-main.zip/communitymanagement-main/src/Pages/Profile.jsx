import ProfileCard from "../Components/ProfileCard";

export default function Profile() {
  return (
    <div className="w-full h-screen mx-10 grid grid-flow-col grid-cols-2 gap-5 p-5">
      <div id="profileupdate" className="flex items-center justify-center">
        <ProfileCard />
      </div>
      <div id="pastData">
        <div className="form-control">
          <label className="label">
            <span className="label-text">Search</span>
          </label>

          <input
            className="input input-bordered relative"
            placeholder="Search"
          />
          <span className="absolute top-[139px] left-[1400px]">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-6 w-6"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
              />
            </svg>
          </span>
        </div>
        <div className="border h-[598px] overflow-auto p-10 my-5">
          <div className="flex items-center justify-center flex-col gap-5">
            <div className="card w-96 bg-success text-neutral-content relative">
              <div className="card-body items-center text-center">
                <h2 className="card-title">Issue Name</h2>
                <p>Description............</p>
                <p>Location............</p>
                <p>Link to ward............</p>
                <div className="card-actions justify-end">
                  <button className="btn btn-warning">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-6 w-6"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      strokeWidth={2}
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                      />
                    </svg>
                  </button>
                </div>
              </div>
              <p className="badge absolute top-2 right-3">Pending</p>
            </div>
            <div className="card w-96 bg-success text-neutral-content relative">
              <div className="card-body items-center text-center">
                <h2 className="card-title">Issue Name</h2>
                <p>Description............</p>
                <p>Location............</p>
                <p>Link to ward............</p>
                <div className="card-actions justify-end">
                  <button className="btn btn-warning">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-6 w-6"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      strokeWidth={2}
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                      />
                    </svg>
                  </button>
                </div>
              </div>
              <p className="badge absolute top-2 right-3">Pending</p>
            </div>
            <div className="card w-96 bg-success text-neutral-content relative">
              <div className="card-body items-center text-center">
                <h2 className="card-title">Issue Name</h2>
                <p>Description............</p>
                <p>Location............</p>
                <p>Link to ward............</p>
                <div className="card-actions justify-end">
                  <button className="btn btn-warning">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-6 w-6"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      strokeWidth={2}
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                      />
                    </svg>
                  </button>
                </div>
              </div>
              <p className="badge absolute top-2 right-3">Pending</p>
            </div>
            <div className="card w-96 bg-success text-neutral-content relative">
              <div className="card-body items-center text-center">
                <h2 className="card-title">Issue Name</h2>
                <p>Description............</p>
                <p>Location............</p>
                <p>Link to ward............</p>
                <div className="card-actions justify-end">
                  <button className="btn btn-warning">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-6 w-6"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      strokeWidth={2}
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                      />
                    </svg>
                  </button>
                </div>
              </div>
              <p className="badge absolute top-2 right-3">Pending</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
