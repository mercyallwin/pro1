import { useState } from "react";
import Events from "./Events";
import Issues from "./Issues";
import Needs from "./Needs";

export default function Forms({ closeModal }) {
  const [formIndex, setFormIndex] = useState(1);
  return (
    <div className="card border shadow-xl bg-white absolute inset-0 w-1/2  mx-96 my-20">
      <div id="card-head" className="m-2">
        <div className="tabs w-full flex items-start justify-between mt-4">
          <div>
            <div
              onClick={() => setFormIndex(1)}
              className={
                formIndex === 1 ? "tab tab-lifted tab-active" : "tab tab-lifted"
              }
            >
              Issues
            </div>
            <div
              onClick={() => setFormIndex(2)}
              className={
                formIndex === 2 ? "tab tab-lifted tab-active" : "tab tab-lifted"
              }
            >
              Needs
            </div>
            <div
              onClick={() => setFormIndex(3)}
              className={
                formIndex === 3 ? "tab tab-lifted tab-active" : "tab tab-lifted"
              }
            >
              Events
            </div>
          </div>
          <div onClick={() => closeModal()} className="cursor-pointer">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-6 w-6"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"
              />
            </svg>
          </div>
        </div>
      </div>
      <div id="card-body" className="m-2">
        {formIndex === 1 && <Issues />}
        {formIndex === 2 && <Needs />}
        {formIndex === 3 && <Events />}
      </div>
    </div>
  );
}
