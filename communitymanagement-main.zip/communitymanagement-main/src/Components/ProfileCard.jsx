import React from "react";

export default function ProfileCard() {
  return (
    <div class="card lg:card-side bg-base-100 shadow-xl w-full">
      <figure>
        <div class="avatar">
          <div class="rounded-xl">
            <img src="https://api.lorem.space/image/face?hash=64318" />
          </div>
        </div>
      </figure>
      <div class="card-body">
        <h2 class="card-title font-bold text-4xl">User Info</h2>
        <div className="form-control">
          <label className="label">
            <span className="label-text">Name</span>
          </label>
          <input className="input input-bordered" placeholder="Name" />
        </div>
        <div className="form-control">
          <label className="label">
            <span className="label-text">Description</span>
          </label>
          <input className="input input-bordered" placeholder="Description" />
        </div>
        <div className="form-control">
          <label className="label">
            <span className="label-text">Address</span>
          </label>
          <textarea
            className="input input-bordered h-20"
            placeholder="Address"
          />
        </div>
        <div className="form-control">
          <label className="label">
            <span className="label-text">Conatct Number</span>
          </label>
          <input className="input input-bordered" placeholder="Mobile no" />
        </div>
        <div className="form-control">
          <label className="label">
            <span className="label-text">Email id</span>
          </label>
          <input className="input input-bordered" placeholder="Eamil Id" />
        </div>
        <div class="card-actions justify-center">
          <button class="btn btn-success">Update</button>
        </div>
      </div>
    </div>
  );
}
