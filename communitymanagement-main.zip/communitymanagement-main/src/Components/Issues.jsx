import React from "react";

export default function Issues() {
  return (
    <form id="issuesForm" className=" grid grid-flow-row grid-cols-3 gap-5 m-5">
      <div className="form-control">
        <label className="label">
          <span className="label-text">Category</span>
        </label>
        <select className="select-bordered select">
          <option>Select</option>
          <option>Category 1</option>
          <option>Category 2</option>
          <option>Category 3</option>
        </select>
      </div>
      <div className="form-control">
        <label className="label">
          <span className="label-text ">Describe Issue</span>
        </label>
        <input className="input input-bordered " placeholder="Issue" />
      </div>
      <div className="form-control">
        <label className="label">
          <span className="label-text ">Location</span>
        </label>
        <textarea className="input input-bordered h-20" placeholder="Address" />
      </div>
      <div className="form-control">
        <label className="label">
          <span className="label-text ">Country</span>
        </label>
        <input className="input input-bordered " placeholder="Country" />
      </div>
      <div className="form-control">
        <label className="label">
          <span className="label-text">State</span>
        </label>
        <select className="select-bordered select">
          <option>Select</option>
          <option>Category 1</option>
          <option>Category 2</option>
          <option>Category 3</option>
        </select>
      </div>
      <div className="form-control">
        <label className="label">
          <span className="label-text ">City</span>
        </label>
        <input className="input input-bordered " placeholder="City" />
      </div>
      <div className="form-control">
        <label className="label">
          <span className="label-text ">Pincode</span>
        </label>
        <input className="input input-bordered " placeholder="Pincode" />
      </div>
      <div className="form-control">
        <label className="label">
          <span className="label-text ">Website Link</span>
        </label>
        <input className="input input-bordered " placeholder="Link" />
      </div>
      <div className="form-control mt-7">
        <label className="cursor-pointer label">
          <span className="label-text">
            Accept Consent that the above information is true
          </span>
          <input type="checkbox" className="checkbox checkbox-accent" />
        </label>
      </div>
      <div className="form-control mt-10 col-start-2">
        <button className="btn btn-success">
          <span className="mr-2">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-6 w-6"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4"
              />
            </svg>
          </span>
          Submit
        </button>
      </div>
    </form>
  );
}
