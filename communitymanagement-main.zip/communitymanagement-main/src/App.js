import { Link, Outlet } from "react-router-dom";

function App() {
  return (
    <div className="h-screen">
      <div className="navbar bg-success text-primary-content">
        <div>
          <div className="dropdown">
            <label
              tabindex="0"
              class="btn m-1 bg-success border-0 hover:bg-green-500"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                strokeWidth={2}
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M4 6h16M4 12h16M4 18h16"
                />
              </svg>
            </label>
            <ul
              tabindex="0"
              className="dropdown-content menu p-2 shadow bg-base-100 rounded-box w-52"
            >
              <li>
                <Link to={"/"} className="text-black">
                  Home
                </Link>
              </li>
              <li>
                <Link to={"/profile"} className="text-black">
                  Profile
                </Link>
              </li>
              <li>
                <Link to={"/"} className="text-black">
                  About
                </Link>
              </li>
              <li>
                <Link to={"/"} className="text-black">
                  Help
                </Link>
              </li>
              <li>
                <Link to={"/"} className="text-black">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="flex items-center justify-center w-full mx-10">
          <Link to={"/"} className="btn btn-ghost normal-case text-xl">
            Community Management
          </Link>
        </div>
        <div className="flex gap-5">
          <Link className="text-base font-bold" to={"/login"}>
            Login
          </Link>
          <Link className="text-base font-bold" to={"/signup"}>
            Signup
          </Link>
        </div>
      </div>
      <div className="flex items-center justify-center ">
        <Outlet />
      </div>
    </div>
  );
}

export default App;
